""" Definition for the generic Model class """


class Model:
    def __init__(self, n_classes, input_height=None, input_width=None):
        pass
